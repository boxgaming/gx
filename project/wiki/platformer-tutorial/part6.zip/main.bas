'$Include: 'lib/gx.bi'
Const MOVE_RIGHT = 1
Const MOVE_LEFT = 2
Const ACCEL = 7
Const MAX_VELOCITY = 120

Dim Shared direction As Integer
direction = MOVE_RIGHT

GXSceneCreate 256, 144
GXSceneScale 2

LoadMap

' Create the player
Dim Shared player As Long
player = GXEntityCreate("img/character.png", 16, 20, 4)
GXEntityPos player, 120, 75
GXEntityApplyGravity player, GX_TRUE
GXEntityCollisionOffset player, 3, 5, 3, 0

GXSceneStart

mapLayer1:
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1
Data 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,13
Data 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,13
Data 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,13
Data 15, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0,13
Data 15, 0, 0, 0, 0, 0, 0,13,15, 0, 0, 0, 0, 0, 0,13
Data 28, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,30

mapLayer2:
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  0, 0,53,54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
Data  0, 0,65,66, 0, 0, 0, 0, 0, 0, 0, 0,50, 0, 0, 0
Data  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

Sub GXOnGameEvent (e As GXEvent)
    Select Case e.event
        Case GXEVENT_UPDATE: OnUpdate e
        Case GXEVENT_COLLISION_TILE: OnTileCollision e
    End Select
End Sub

Sub OnUpdate (e As GXEvent)
    HandlePlayerMovement e
End Sub

Sub OnTileCollision(e As GXEvent)
    If GXMapTile(e.collisionTileX, e.collisionTileY, 1) Then
        e.collisionResult = GX_TRUE
    End If
End Sub

Sub LoadMap
    GXTilesetCreate "img/tileset.png", 16, 16
    GXMapCreate 16, 9, 2

    Dim As Integer col, row, tile, layer
    For layer = 1 To GXMapLayers
        For row = 0 To GXSceneRows - 1
            For col = 0 To GXSceneColumns - 1
                Read tile
                GXMapTile col, row, layer, tile
            Next col
        Next row
    Next layer
End Sub

Sub HandlePlayerMovement (e As GXEvent)
    Dim As Integer vx, vy
    vx = GXEntityVX(player)
    vy = GXEntityVY(player)

    ' move left
    If GXKeyDown(GXKEY_LEFT) Then
        vx = vx - ACCEL
        If vx < MAX_VELOCITY * -1 Then vx = MAX_VELOCITY * -1
        direction = MOVE_LEFT
        GXEntityAnimate player, direction, 15

    ' move right
    ElseIf GXKeyDown(GXKEY_RIGHT) Then
        vx = vx + ACCEL
        If vx > MAX_VELOCITY Then vx = MAX_VELOCITY
        direction = MOVE_RIGHT
        GXEntityAnimate player, direction, 15

    ' slow down when a direction key is not pressed
    ElseIf vx > 0 Then
        vx = vx - ACCEL
        If vx < 0 Then vx = 0

    ElseIf vx < 0 Then
        vx = vx + ACCEL
        If vx > 0 Then vx = 0

    Else
        GXEntityAnimateStop player
    End If
    
    GXEntityVX player, vx


    If GXEntityVY(player) = 0 And GXKeyDown(GXKEY_SPACEBAR) Then
        GXEntityVY player, -260
    End If

    ' fall faster for a less "floaty" jump
    If vy > 0 Then
        GXEntityVY player, vy + 25
    ElseIf vy < 0 Then
        GXEntityVY player, vy + 10
    End If

    ' show jump frame
    If vy <> 0 Then
        GXEntityAnimateStop player
        GXEntityFrameSet player, direction, 2
    End If

    ' idle
    If vy = 0 And vx = 0 Then
        GXEntityAnimateStop player
        GXEntityFrameSet player, direction, 1
    End If
    
End Sub

'$Include: 'lib/gx.bm'
