'$Include: 'lib/gx.bi'
Const MOVE_RIGHT = 1
Const MOVE_LEFT = 2
Const ACCEL = 7
Const MAX_VELOCITY = 120
Const COLLISION_LAYER = 3
Const COLLISION_TILE = 72
Const COLLISION_TILE2 = 71

Dim Shared direction As Integer
direction = MOVE_RIGHT

' Create the scene
GXSceneCreate 256, 144
GXSceneScale 2

' Create the backgrounds
Dim As Long bg1
bg1 = GXBackgroundAdd("img/clouds.png", GXBG_STRETCH)
bg2 = GXBackgroundAdd("img/mountains.png", GXBG_WRAP)
GXBackgroundWrapFactor bg2, .25

' Create the map
GXMapLoad "map/platformer.gxm"
GXMapLayerVisible COLLISION_LAYER, GX_FALSE

' Create the player
Dim Shared player As Long
player = GXEntityCreate("img/character.png", 16, 20, 4)
GXEntityPos player, 120, 75
GXEntityApplyGravity player, GX_TRUE
GXEntityCollisionOffset player, 3, 5, 3, 0

GXSceneFollowEntity player, GXSCENE_FOLLOW_ENTITY_CENTER
GXSceneConstrain GXSCENE_CONSTRAIN_TO_MAP

GXSceneStart

Sub GXOnGameEvent (e As GXEvent)
    Select Case e.event
        Case GXEVENT_UPDATE: OnUpdate e
        Case GXEVENT_COLLISION_TILE: OnTileCollision e
    End Select
End Sub

Sub OnUpdate (e As GXEvent)
    HandlePlayerMovement e
End Sub

Sub OnTileCollision (e As GXEvent)
    Dim ctile
    ctile = GXMapTile(e.collisionTileX, e.collisionTileY, COLLISION_LAYER)
    
    If ctile = COLLISION_TILE Then
        e.collisionResult = GX_TRUE

    ElseIf ctile = COLLISION_TILE2 Then
        If GXEntityVY(e.entity) >= 0 Then
            If GXEntityY(e.entity) + GXEntityHeight(e.entity) < e.collisionTileY * GXTilesetHeight + 1 Then
                e.collisionResult = GX_TRUE
            End If
        End If
    End If
End Sub

Sub HandlePlayerMovement (e As GXEvent)
    Dim As Integer vx, vy
    vx = GXEntityVX(player)
    vy = GXEntityVY(player)

    ' move left
    If GXKeyDown(GXKEY_LEFT) Then
        vx = vx - ACCEL
        If vx < MAX_VELOCITY * -1 Then vx = MAX_VELOCITY * -1
        direction = MOVE_LEFT
        GXEntityAnimate player, direction, 15

    ' move right
    ElseIf GXKeyDown(GXKEY_RIGHT) Then
        vx = vx + ACCEL
        If vx > MAX_VELOCITY Then vx = MAX_VELOCITY
        direction = MOVE_RIGHT
        GXEntityAnimate player, direction, 15

    ' slow down when a direction key is not pressed
    ElseIf vx > 0 Then
        vx = vx - ACCEL
        If vx < 0 Then vx = 0

    ElseIf vx < 0 Then
        vx = vx + ACCEL
        If vx > 0 Then vx = 0

    Else
        GXEntityAnimateStop player
    End If
    
    GXEntityVX player, vx


    If GXEntityVY(player) = 0 And GXKeyDown(GXKEY_SPACEBAR) Then
        GXEntityVY player, -260
    End If

    ' fall faster for a less "floaty" jump
    If vy > 0 Then
        GXEntityVY player, vy + 25
    ElseIf vy < 0 Then
        GXEntityVY player, vy + 10
    End If

    ' show jump frame
    If vy <> 0 Then
        GXEntityAnimateStop player
        GXEntityFrameSet player, direction, 2
    End If

    ' idle
    If vy = 0 And vx = 0 Then
        GXEntityAnimateStop player
        GXEntityFrameSet player, direction, 1
    End If
    
End Sub

'$Include: 'lib/gx.bm'
