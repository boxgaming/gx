'$Include: 'lib/gx.bi'
Const MOVE_RIGHT = 1
Const MOVE_LEFT = 2

GXSceneCreate 256, 144
GXSceneScale 2

' Create the player
Dim Shared player As Long
player = GXEntityCreate("img/character.png", 16, 20, 4)
GXEntityPos player, 120, 75

GXSceneStart

Sub GXOnGameEvent (e As GXEvent)
    Select Case e.event
        Case GXEVENT_UPDATE: OnUpdate e
    End Select
End Sub

Sub OnUpdate (e As GXEvent)
    If GXKeyDown(GXKEY_LEFT) Then
        GXEntityVX player, -40
        GXEntityAnimate player, MOVE_LEFT, 10

    ElseIf GXKeyDown(GXKEY_RIGHT) Then
        GXEntityVX player, 40
        GXEntityAnimate player, MOVE_RIGHT, 10

    Else
        GXEntityVX player, 0
        GXEntityAnimateStop player
    End If
End Sub

'$Include: 'lib/gx.bm'
